module.exports = {

	openurl: true

}