module.exports = {
	public: false,
	realm: "my realm",
	secret: "SomeApiSecretHereForSalting"
}