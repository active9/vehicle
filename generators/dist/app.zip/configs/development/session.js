module.exports = {

	secret: 'my secret key',
	resave: false,
	saveUninitialized: true

}