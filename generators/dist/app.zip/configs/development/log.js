module_exports = {

	dir: '/logs',
	format: 'combined',
	access: true,
	access_log: 'access.log'

}