module.exports = {

	cors: true,
	allRoutes: false

}