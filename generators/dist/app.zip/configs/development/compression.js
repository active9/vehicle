module.exports = {

	compress: false

}