module.exports = {

	rest: true

}