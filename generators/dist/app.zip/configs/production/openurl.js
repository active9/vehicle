module.exports = {

	openurl: false

}