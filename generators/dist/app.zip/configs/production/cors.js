module.exports = {

	cors: true

}