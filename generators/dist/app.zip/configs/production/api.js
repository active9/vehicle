module.exports = {
	public: true,
	realm: "my realm",
	secret: "SomeApiSecretHereForSalting"
}