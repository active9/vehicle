module.exports = {

	compress: true

}