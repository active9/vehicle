module.exports = {
		"identity": "pet",
		"connection": "myLocalDisk",
		"attributes": {
			"name": "string",
			"breed": "string"
		}
}