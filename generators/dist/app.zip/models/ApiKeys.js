module.exports = {
		"identity": "apikeys",
		"connection": "myLocalDisk",
		"attributes": {
			"key": "string"
		}
}