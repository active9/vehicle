Vinegar.js
==========

[VinegarJS.com](http://www.vinegarjs.com/)

A Simple Robust Javascript &lt;{Template Engine}>

INSTALL:
include the Vinegar.js file in the head of your page or project.

USAGE:
Check out the examples folder!
