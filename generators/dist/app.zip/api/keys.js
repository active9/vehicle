modlue.exports = function(key, fn) {

	if ('test' === key)
		fn(null, { id: '1', name: 'John Dorian'})
	else
		fn(null, null)

}