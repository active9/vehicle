/*
 * Vehicle - Test Application
 */

module.exports = function (app,rc,express,weiv,orm,drivers,passport,__basedir) {

	// App Config
	var config = require("./config.json");

	// Routes
	for (route in config.routes) {
		rc(app, require('./routes/'+ config.routes[route]));
	}

	// Strategies
	if (require("./configs/"+process.env.NODE_ENV+"/passport.js").enabled)
		var strategies = require('./strategies/strategies.js')(app,rc,express,weiv,orm,drivers,passport,__basedir);

	// Assets Directory
	app.use('/assets', express.static(__basedir + '/assets'));

	// Fixed Index
	app.get('/', function(req, res) {
		var template = __basedir + "/views/index.html";
		weiv.view(template, res, [{VEHICLE: "Vehicle"}]);
	});

}