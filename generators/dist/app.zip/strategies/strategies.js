var LocalStrategy = require('passport-local');

module.exports = function (app,rc,express,weiv,orm,drivers,passport,__basedir) {

	var local = require('./users.js')(passport,drivers.user);

	app.post('/login', 
		passport.authenticate('local', { failureRedirect: '/login' }),
		function(req, res) {
			res.redirect('/');
		}
	);

}