var vehicle = require('../server.js');
var path = require('path');
var script = path.resolve(__dirname);
process.chdir(path.resolve(__dirname));

console.log("VEHICLE:", script);

vehicle({
	"app": script
});