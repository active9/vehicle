/*
 * API Controller - An api test example controller that accesses the waterline object models
 *
 */
module.exports = {
    api: function(req, res) {
	res.json(Object.keys(res.app.models));
    }
};